<template>
   <nav class="container flex items-center py-4 mt-4 sm:mt-12">
    
    <div class="py-1"><img src="../assets/images/podcast.png" width="60" alt="podcast logo"></div>
      <ul class="hidden sm:flex flex-1 justify-end items-center gap-12 text-bookmark-blue uppercase text-xs">
        <li class="cursor-pointer text-white">Features</li>
        <li class="cursor-pointer text-white">Pricing</li>
        <li class="cursor-pointer text-white">Contact</li>
        <button type="button" class="bg-bookmark-red text-white rounded-md px-7 py-3 uppercase">Login</button>
      </ul>
      <div class="flex sm:hidden flex-1 justify-end"><i class="text-xl fas fa-bars text-white cursor-pointer"></i></div>
  </nav>
</template>

<script setup>


</script>

