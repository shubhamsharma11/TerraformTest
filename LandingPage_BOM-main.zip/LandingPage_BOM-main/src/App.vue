<template>
  <Navigation />
  <Hero />
  <Features />
  <Contact />
  <Footer />
  
</template>

<script setup>
import Navigation from './components/Navigation.vue';
import Hero from './components/Hero.vue';
import Features from './components/Features.vue';
import Contact from './components/Contact.vue';
import Footer from './components/Footer.vue';


</script>

<style>
body {
  background-color: #040b12;
}
</style>
