## Objective
  Deploy website on linux machine using docker via the Azure pipeline.

## Part-2: Using the Gui on the Azure pipeline for build and push of the docker image.

### Steps: 

1.	Create Azure pipeline 
    a.	Build an image 
    b.	Push an image  to ACR

